
const get = id => document.getElementById(id);

let totalChecks = 0;
let successfulChecks = 0;
let failedChecks = 0;
let checking = false;

function updateLights(connected) {
  get("greenLed").classList.toggle("active", connected);
  get("redLed").classList.toggle("active", !connected);

  const badge = get("signalBadge");
  badge.className = "signal-badge " +
    (connected ? "connected" : "disconnected");
  badge.textContent = connected ? "Green verified" : "Red verified";

  get("currentStatus").textContent =
    connected ? "CONNECTED" : "DISCONNECTED";

  get("statusDescription").textContent = connected
    ? "The monitored EC2 endpoint is responding successfully."
    : "The monitored EC2 endpoint is not responding.";
}

function addHistory(time, connected, latency) {
  const container = get("historyRows");

  if (totalChecks === 1) container.innerHTML = "";

  const row = document.createElement("div");
  row.className = "history-row";

  const timeCell = document.createElement("span");
  timeCell.textContent = time;

  const statusCell = document.createElement("span");
  statusCell.className = connected ? "ok" : "bad";
  statusCell.textContent = connected
    ? "● CONNECTED" : "● DISCONNECTED";

  const latencyCell = document.createElement("span");
  latencyCell.textContent = latency === null
    ? "--" : latency.toFixed(1) + " ms";

  row.append(timeCell, statusCell, latencyCell);
  container.prepend(row);

  while (container.children.length > 10) {
    container.lastElementChild.remove();
  }
}

async function refreshStatus() {
  if (checking) return;
  checking = true;
if (get("manualRefresh")) {
  get("manualRefresh").disabled = true;
}

  try {
    const response = await fetch("/api/status", {
      cache: "no-store"
    });

    if (!response.ok) throw new Error("Status API unavailable");

    const data = await response.json();
    const connected = data.connected === true;
    const latency = typeof data.latency_ms === "number"
      ? data.latency_ms : null;

    const checkedDate = new Date(data.checked_at);
    const time = Number.isNaN(checkedDate.getTime())
      ? new Date().toLocaleTimeString()
      : checkedDate.toLocaleTimeString();

    totalChecks++;
    if (connected) successfulChecks++;
    else failedChecks++;

    updateLights(connected);

    get("targetIP").textContent = data.target_ip || "--";
    get("latency").textContent = latency === null
      ? "-- ms" : latency.toFixed(1) + " ms";
    get("lastChecked").textContent = time;

    const percentage =
      (successfulChecks / totalChecks * 100).toFixed(1) + "%";

    get("successRate").textContent = percentage;
    get("uptime").textContent = percentage;
    get("totalChecks").textContent = totalChecks;
    get("successfulChecks").textContent = successfulChecks;
    get("failedChecks").textContent = failedChecks;

    addHistory(time, connected, latency);

  } catch (error) {
    // Do not mistake a monitoring API error for a failed ping.
    get("greenLed").classList.remove("active");
    get("redLed").classList.remove("active");
    get("signalBadge").className = "signal-badge";
    get("signalBadge").textContent = "Status unknown";
    get("currentStatus").textContent = "MONITOR UNAVAILABLE";
    get("statusDescription").textContent =
      "Unable to retrieve the monitoring result from Flask.";
    console.error(error);
  } finally {
    checking = false;
    if (get("manualRefresh")) {
  get("manualRefresh").disabled = false;
}
  }
}

const refreshButton = get("manualRefresh");

if (refreshButton) {
  refreshButton.addEventListener("click", refreshStatus);
}

refreshStatus();
setInterval(refreshStatus, 3000);
